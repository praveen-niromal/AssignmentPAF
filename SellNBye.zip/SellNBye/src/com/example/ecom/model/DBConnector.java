package com.example.ecom.model;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnector {

	public static Connection createConnection() {
		Connection con=null;
		String url="jdbc:nysql://localhost:3306/users";
		String username= "root";
		String password="";
		
		try {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO: handle exception
				e.printStackTrace();
			}
			
			con=DriverManager.getConnection(url, username, password);
			System.out.println("Printing connection object" +con);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return con;
	}
}
